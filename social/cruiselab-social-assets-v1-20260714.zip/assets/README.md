# The Cruise Lab — Social Media Asset Pack v1 (2026-07-14)

Brand-accurate avatar and banner set for The Cruise Lab social accounts.
Handle locked across all platforms: **@thecruiselabhq**. Display name everywhere: **The Cruise Lab**.

All artwork is generated from the live hub's flask mark and the Cruise Lab design tokens
(midnight navy #081830 / #0d2445, champagne gold #d9b45c → #f0d087, sea-glass #46c3a8,
Cinzel display, Outfit body). The flask here is a **static** version of the animated hub mark
(heavier stroke, no animation) so it stays legible when platforms shrink it to ~40px.

---

## What's in the pack

### Avatars (profile pictures)
| File | Size | Use |
|---|---|---|
| `avatar-roundel-master.png` | 1000×1000 | Master. Upload this anywhere that accepts a large square; platform down-scales it. |
| `avatar-roundel-400.png` | 400×400 | General profile pic (TikTok, X, Threads, Bluesky, Pinterest). |
| `avatar-roundel-320.png` | 320×320 | Instagram (recommended upload ≥320). |
| `avatar-roundel-180.png` | 180×180 | Facebook page profile (min 170). |
| `avatar-roundel-150.png` | 150×150 | Small fallback. |
| `avatar-roundel-98.png` | 98×98 | Sanity-check of how the mark reads tiny — not usually uploaded. |
| `avatar-square-master.png` | 1000×1000 | Full-bleed square (no gold ring) for any use that wants edge-to-edge. |
| `avatar-square-800.png` | 800×800 | Same, smaller. |

**Which avatar?** Use the **roundel** version everywhere — the gold ring frames the flask nicely
inside the circular crop every platform applies. The square (ringless) version is only for the
rare spot that shows the avatar as an actual square.

### Banners / headers / covers
| File | Size | Platform |
|---|---|---|
| `banner-youtube-2560x1440.png` | 2560×1440 | YouTube channel art. Content sits inside the 1546×423 TV-safe centre, so it survives every device crop. |
| `banner-x-1500x500.png` | 1500×500 | X / Twitter header. |
| `banner-facebook-1640x624.png` | 1640×624 | Facebook Page cover. |
| `banner-linkedin-1584x396.png` | 1584×396 | LinkedIn (only if/when you use it). |
| `banner-pinterest-800x450.png` | 800×450 | Pinterest — cover / share image. |

> **Instagram & TikTok have no banner** — they're avatar + bio only. Nothing to upload there
> beyond the avatar.

### Editable source
| File | Notes |
|---|---|
| `avatar-roundel.svg` | Vector master for the roundel avatar. |
| `avatar-square.svg` | Vector master for the square avatar. |
| `banner-master-2560x1440.svg` | Vector master for the banner lockup. |

Edit the SVGs in any vector editor (or by hand — they're plain text) and re-export at the sizes
above. Colours are literal hex from the design tokens; the fonts are Cinzel (700) and Outfit
(300/500), both free from Google Fonts.

---

## Bios (paste at signup)

**Display name (all platforms):** The Cruise Lab

**Handle (all platforms):** @thecruiselabhq

**Bio:**
```
⚓ The account that runs the numbers on cruising
🧪 Cabin scores · bar tabs · casino points · port guides
🔗 All free tools ↓
```
Link: `https://thecruiselab.com` for now — swap to `https://links.thecruiselab.com`
once the link hub is built.

---

## Upload cheat-sheet

- **Instagram:** avatar-roundel-320. No banner.
- **TikTok:** avatar-roundel-400. No banner.
- **YouTube:** avatar-roundel-400 (channel icon) + banner-youtube-2560x1440 (channel art).
- **Facebook Page:** avatar-roundel-180 + banner-facebook-1640x624.
- **Pinterest:** avatar-roundel-400 + banner-pinterest-800x450.
- **X:** avatar-roundel-400 + banner-x-1500x500.
- **Threads / Bluesky:** avatar-roundel-400. (Threads pulls from Instagram if linked.)

---

## How it was built

- Flask geometry lifted verbatim from `hub/index.html` (the live animated mark), rendered static.
- Master SVGs generated with the Cruise Lab tokens; text laid out with measured font metrics so
  the flask + wordmark + tagline lockup stays centred and inside each platform's safe area.
- Rasterised to PNG with cairosvg at each platform's exact pixel dimensions.
- Fonts: Cinzel & Outfit (OFL, Google Fonts).

To regenerate: the two build scripts (`build_assets.py`, `build_banners.py`) live with the
delivery; they need `cairosvg`, `Pillow`, and the two TTFs in `/tmp/fonts` (or adjust paths).
