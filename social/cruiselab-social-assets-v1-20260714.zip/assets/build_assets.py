#!/usr/bin/env python3
"""Generate The Cruise Lab social media asset set (avatars + banners) from
brand-accurate master SVGs, rasterised to every platform's required size."""
import cairosvg, os

OUT = "/tmp/assets"
os.makedirs(OUT, exist_ok=True)

# ---- Brand tokens (from master context) ----
OCEAN_DEEP = "#081830"
OCEAN      = "#0d2445"
PANEL_EDGE = "#1d3d6b"
GOLD       = "#d9b45c"
GOLD_BRIGHT= "#f0d087"
FOAM       = "#f3efe4"
MIST       = "#8fa2bd"
SEAGLASS   = "#46c3a8"

# ---------- Shared flask geometry (from live hub, avatar-tuned) ----------
# Original path uses viewBox 0 0 100 110. We reuse the exact path but present
# it statically (no animation) with a slightly heavier stroke so it survives
# downscaling to 40px.
FLASK_PATH = "M42 12 h16 v26 l24 46 c4 8 -2 18 -11 18 H29 c-9 0 -15 -10 -11 -18 l24 -46 z"

def flask_group(stroke_w=3.4, cx=50, scale=1.0, tx=0, ty=0):
    """Return the flask as a self-contained <g>, statically filled with sea."""
    return f'''
    <g transform="translate({tx},{ty}) scale({scale})">
      <defs>
        <clipPath id="fc">
          <path d="{FLASK_PATH}"/>
        </clipPath>
        <linearGradient id="gs" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="{GOLD_BRIGHT}"/>
          <stop offset="1" stop-color="{GOLD}"/>
        </linearGradient>
      </defs>
      <g clip-path="url(#fc)">
        <rect x="0" y="66" width="100" height="44" fill="{OCEAN}"/>
        <path fill="{PANEL_EDGE}"
          d="M-14 68 q7 -5 14 0 t14 0 t14 0 t14 0 t14 0 t14 0 t14 0 t14 0 v44 h-126 z"/>
        <path fill="{SEAGLASS}" opacity=".35"
          d="M-14 72 q7 -4 14 0 t14 0 t14 0 t14 0 t14 0 t14 0 t14 0 t14 0 v40 h-126 z"/>
      </g>
      <path d="{FLASK_PATH}" fill="none" stroke="url(#gs)"
        stroke-width="{stroke_w}" stroke-linejoin="round"/>
      <path d="M38 12 h24" stroke="url(#gs)" stroke-width="{stroke_w}" stroke-linecap="round"/>
      <circle cx="{cx}" cy="52" r="4.2" fill="{GOLD_BRIGHT}" opacity=".95"/>
    </g>'''

# ---------------- AVATAR master (square, 1000x1000) ----------------
# Navy roundel background with a subtle gold ring, flask centred.
def avatar_svg(size=1000, ring=True):
    r = size/2
    ring_el = (f'<circle cx="{r}" cy="{r}" r="{r-size*0.045}" fill="none" '
               f'stroke="{GOLD}" stroke-width="{size*0.012}" opacity="0.55"/>') if ring else ''
    # flask occupies ~54% of the canvas, centred. Original viewBox 100x110.
    fs = size*0.0052            # scale factor for 100-unit flask
    fw = 100*fs                 # rendered flask width
    fh = 110*fs
    tx = (size-fw)/2
    ty = (size-fh)/2 + size*0.01
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}">
  <defs>
    <radialGradient id="bg" cx="50%" cy="42%" r="72%">
      <stop offset="0" stop-color="{OCEAN}"/>
      <stop offset="1" stop-color="{OCEAN_DEEP}"/>
    </radialGradient>
  </defs>
  <rect width="{size}" height="{size}" fill="{OCEAN_DEEP}"/>
  <circle cx="{r}" cy="{r}" r="{r}" fill="url(#bg)"/>
  {ring_el}
  {flask_group(stroke_w=3.2, tx=tx, ty=ty, scale=fs)}
</svg>'''

# Square avatar with no roundel (for platforms that crop to circle themselves
# but show square in some places) — same but full-bleed navy, no ring inset.
def avatar_square_svg(size=1000):
    fs = size*0.0052
    fw = 100*fs; fh = 110*fs
    tx = (size-fw)/2; ty = (size-fh)/2 + size*0.01
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}">
  <defs>
    <radialGradient id="bg" cx="50%" cy="42%" r="80%">
      <stop offset="0" stop-color="{OCEAN}"/>
      <stop offset="1" stop-color="{OCEAN_DEEP}"/>
    </radialGradient>
  </defs>
  <rect width="{size}" height="{size}" fill="url(#bg)"/>
  {flask_group(stroke_w=3.2, tx=tx, ty=ty, scale=fs)}
</svg>'''

# ---------------- BANNER master ----------------
# Wide navy field, flask on the left, Cinzel wordmark + tagline to the right.
# Built at a generous master resolution then cropped per platform via viewBox.
def banner_svg(w, h, tagline=True, safe_center=False):
    # Layout scales with height.
    pad = h*0.16
    flask_h = h*0.62
    flask_scale = flask_h/110
    flask_w = 100*flask_scale
    fx = pad*1.1
    fy = (h-flask_h)/2
    # text block
    text_x = fx + flask_w + h*0.14
    wordmark_size = h*0.26
    tagline_size = h*0.093
    baseline = h*0.5
    # If safe_center, push content toward centre (YouTube TV-safe area).
    if safe_center:
        block_w = flask_w + h*0.14 + wordmark_size*7.2
        start = (w-block_w)/2
        fx = start
        text_x = fx + flask_w + h*0.14
        fy = (h-flask_h)/2

    wordmark_y = baseline - (tagline_size*0.4 if tagline else -wordmark_size*0.35)
    tag_y = baseline + tagline_size*1.15

    tagline_el = (f'''<text x="{text_x}" y="{tag_y}" font-family="Outfit"
        font-weight="300" font-size="{tagline_size}" fill="{MIST}"
        letter-spacing="0.5">Free web tools built <tspan fill="{FOAM}" font-weight="500">by a cruiser, for cruisers</tspan></text>'''
        if tagline else '')

    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}">
  <defs>
    <linearGradient id="bgw" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="{OCEAN}"/>
      <stop offset="1" stop-color="{OCEAN_DEEP}"/>
    </linearGradient>
    <linearGradient id="gold" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="{GOLD_BRIGHT}"/>
      <stop offset="1" stop-color="{GOLD}"/>
    </linearGradient>
    <radialGradient id="glow" cx="18%" cy="50%" r="55%">
      <stop offset="0" stop-color="{GOLD}" stop-opacity="0.10"/>
      <stop offset="1" stop-color="{GOLD}" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#bgw)"/>
  <rect width="{w}" height="{h}" fill="url(#glow)"/>
  {flask_group(stroke_w=3.0, tx=fx, ty=fy, scale=flask_scale)}
  <text x="{text_x}" y="{wordmark_y}" font-family="Cinzel" font-weight="700"
    font-size="{wordmark_size}" fill="url(#gold)" letter-spacing="1">THE CRUISE LAB</text>
  {tagline_el}
</svg>'''

# ---------------- Render matrix ----------------
jobs = []

# Avatars — one master, many sizes. Instagram/TikTok/Pinterest/X/Threads/Bluesky
# show circle crops; the roundel version is safest everywhere.
for size, label in [(1000,"master"),(400,"400"),(320,"320"),(180,"180"),(150,"150"),(98,"98")]:
    jobs.append(("avatar", avatar_svg(1000), f"avatar-roundel-{label}.png", size, size))
# Square (no ring) variant for platforms/uses that want full-bleed square
for size, label in [(1000,"master"),(800,"800")]:
    jobs.append(("avatar", avatar_square_svg(1000), f"avatar-square-{label}.png", size, size))

# Banners — per platform, correct pixel dims.
banner_specs = [
    # (name, width, height, tagline, safe_center)
    ("banner-youtube-2560x1440", 2560, 1440, True, True),   # YT channel art, TV-safe centre
    ("banner-x-1500x500",        1500, 500,  True, False),   # X / Twitter header
    ("banner-facebook-1640x624", 1640, 624,  True, False),   # FB page cover (desktop safe)
    ("banner-linkedin-1584x396", 1584, 396,  True, False),   # LinkedIn (if used)
    ("banner-pinterest-800x450", 800,  450,  True, False),   # Pinterest profile cover-ish
]
for name, w, h, tag, safe in banner_specs:
    svg = banner_svg(w, h, tagline=tag, safe_center=safe)
    jobs.append(("banner", svg, f"{name}.png", w, h))

# Also drop the raw master SVGs for future editing.
with open(f"{OUT}/avatar-roundel.svg","w") as f: f.write(avatar_svg(1000))
with open(f"{OUT}/avatar-square.svg","w") as f: f.write(avatar_square_svg(1000))
with open(f"{OUT}/banner-master-2560x1440.svg","w") as f: f.write(banner_svg(2560,1440,True,True))

for kind, svg, fname, w, h in jobs:
    cairosvg.svg2png(bytestring=svg.encode(), write_to=f"{OUT}/{fname}",
                     output_width=w, output_height=h)
    print(f"  {fname}  ({w}x{h})")

print("\nDone. Files in", OUT)
