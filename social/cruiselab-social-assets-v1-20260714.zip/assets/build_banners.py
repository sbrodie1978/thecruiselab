#!/usr/bin/env python3
"""Banner generator v2 — measures text with PIL so the flask + wordmark +
tagline lockup is sized and centred correctly for every platform, respecting
each platform's safe area."""
import cairosvg, os
from PIL import ImageFont

OUT = "/tmp/assets"
os.makedirs(OUT, exist_ok=True)

OCEAN_DEEP="#081830"; OCEAN="#0d2445"; PANEL_EDGE="#1d3d6b"
GOLD="#d9b45c"; GOLD_BRIGHT="#f0d087"; FOAM="#f3efe4"; MIST="#8fa2bd"; SEAGLASS="#46c3a8"

CINZEL="/tmp/fonts/Cinzel.ttf"
OUTFIT="/tmp/fonts/Outfit.ttf"
FLASK_PATH="M42 12 h16 v26 l24 46 c4 8 -2 18 -11 18 H29 c-9 0 -15 -10 -11 -18 l24 -46 z"

def measure(text, font_path, px, weight=None):
    # variable fonts: PIL picks default; good enough for layout ratios.
    f = ImageFont.truetype(font_path, px)
    try:
        if weight: f.set_variation_by_axes([weight])
    except Exception: pass
    box = f.getbbox(text)
    return box[2]-box[0], box[3]-box[1]

def flask_group(scale, tx, ty, stroke_w=3.0):
    return f'''<g transform="translate({tx},{ty}) scale({scale})">
      <defs>
        <clipPath id="fc"><path d="{FLASK_PATH}"/></clipPath>
        <linearGradient id="gs" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="{GOLD_BRIGHT}"/><stop offset="1" stop-color="{GOLD}"/>
        </linearGradient>
      </defs>
      <g clip-path="url(#fc)">
        <rect x="0" y="66" width="100" height="44" fill="{OCEAN}"/>
        <path fill="{PANEL_EDGE}" d="M-14 68 q7 -5 14 0 t14 0 t14 0 t14 0 t14 0 t14 0 t14 0 t14 0 v44 h-126 z"/>
        <path fill="{SEAGLASS}" opacity=".35" d="M-14 72 q7 -4 14 0 t14 0 t14 0 t14 0 t14 0 t14 0 t14 0 t14 0 v40 h-126 z"/>
      </g>
      <path d="{FLASK_PATH}" fill="none" stroke="url(#gs)" stroke-width="{stroke_w}" stroke-linejoin="round"/>
      <path d="M38 12 h24" stroke="url(#gs)" stroke-width="{stroke_w}" stroke-linecap="round"/>
      <circle cx="50" cy="52" r="4.2" fill="{GOLD_BRIGHT}" opacity=".95"/>
    </g>'''

def banner(w, h, safe_w=None, safe_h=None, tagline=True):
    """safe_w/safe_h: the centred safe area content must fit inside (for YouTube).
    Defaults to the full canvas with padding."""
    if safe_w is None: safe_w = w*0.86
    if safe_h is None: safe_h = h*0.7

    # Target wordmark height as a fraction of the *safe height*.
    wm_px = safe_h*0.30
    wm_w, _ = measure("THE CRUISE LAB", CINZEL, int(wm_px), weight=700)
    # letter-spacing of 1px per char at this size (14 chars incl spaces ~ +13)
    ls = wm_px*0.02
    wm_w += ls*13

    tag_px = wm_px*0.34
    tag_full = "Free web tools built by a cruiser, for cruisers"
    tag_w, _ = measure(tag_full, OUTFIT, int(tag_px), weight=300)

    flask_h = safe_h*0.78
    flask_scale = flask_h/110.0
    flask_w = 100*flask_scale
    gap = flask_h*0.22

    text_block_w = max(wm_w, tag_w if tagline else 0)
    lockup_w = flask_w + gap + text_block_w

    # If lockup too wide for the safe area, scale everything down proportionally.
    if lockup_w > safe_w:
        k = safe_w/lockup_w
        wm_px*=k; tag_px*=k; ls*=k
        wm_w*=k; tag_w*=k; flask_h*=k; flask_scale*=k; flask_w*=k; gap*=k
        text_block_w*=k; lockup_w=safe_w

    # Centre the lockup in the full canvas.
    start_x = (w - lockup_w)/2
    cy = h/2

    fx = start_x
    fy = cy - flask_h/2
    text_x = fx + flask_w + gap

    # Vertical: wordmark baseline above centre, tagline below.
    if tagline:
        wm_baseline = cy - tag_px*0.15
        tag_baseline = cy + tag_px*1.25
    else:
        wm_baseline = cy + wm_px*0.35

    # split tagline into two coloured runs
    lead = "Free web tools built "
    lead_w, _ = measure(lead, OUTFIT, int(tag_px), weight=300)
    tagline_el = (f'''<text x="{text_x}" y="{tag_baseline}" font-family="Outfit" font-weight="300"
        font-size="{tag_px}" fill="{MIST}">{lead}<tspan fill="{FOAM}" font-weight="500">by a cruiser, for cruisers</tspan></text>'''
        if tagline else '')

    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}">
  <defs>
    <linearGradient id="bgw" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="{OCEAN}"/><stop offset="1" stop-color="{OCEAN_DEEP}"/>
    </linearGradient>
    <linearGradient id="gold" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="{GOLD_BRIGHT}"/><stop offset="1" stop-color="{GOLD}"/>
    </linearGradient>
    <radialGradient id="glow" cx="{(fx+flask_w/2)/w*100:.1f}%" cy="50%" r="60%">
      <stop offset="0" stop-color="{GOLD}" stop-opacity="0.12"/>
      <stop offset="1" stop-color="{GOLD}" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="{w}" height="{h}" fill="url(#bgw)"/>
  <rect width="{w}" height="{h}" fill="url(#glow)"/>
  {flask_group(flask_scale, fx, fy)}
  <text x="{text_x}" y="{wm_baseline}" font-family="Cinzel" font-weight="700"
    font-size="{wm_px}" fill="url(#gold)" letter-spacing="{ls}">THE CRUISE LAB</text>
  {tagline_el}
</svg>'''

specs = [
    # name, w, h, safe_w, safe_h  (safe = centred content box)
    ("banner-youtube-2560x1440", 2560,1440, 1546, 423),   # YT TV-safe area 1546x423 centred
    ("banner-x-1500x500",        1500, 500,  1300, 330, ),
    ("banner-facebook-1640x624", 1640, 624,  1400, 420, ),
    ("banner-linkedin-1584x396", 1584, 396,  1400, 300, ),
    ("banner-pinterest-800x450", 800,  450,  700,  300, ),
]
for spec in specs:
    name,w,h = spec[0],spec[1],spec[2]
    safe_w = spec[3] if len(spec)>3 else None
    safe_h = spec[4] if len(spec)>4 else None
    svg = banner(w,h,safe_w,safe_h,tagline=True)
    cairosvg.svg2png(bytestring=svg.encode(), write_to=f"{OUT}/{name}.png",
                     output_width=w, output_height=h)
    if name.endswith("2560x1440"):
        with open(f"{OUT}/banner-master-2560x1440.svg","w") as f: f.write(svg)
    print(f"  {name}.png")
print("banners done")
